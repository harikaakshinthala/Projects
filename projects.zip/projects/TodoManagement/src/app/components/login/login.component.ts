import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from "sweetalert2"

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;

  constructor(private formBuilder:FormBuilder, private router:Router) { }

  ngOnInit() {
    this. loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]

    });
  }

  onSubmit() {
     
    this.submitted = true;
    if(this.loginForm.invalid){
      return;
    }

    let username = this.loginForm.controls.email.value;
    let password = this.loginForm.controls.password.value;

    if(username == "admin@gmail.com" && password == "Admin123")
    {
      localStorage.setItem("username",username);
      this.router.navigate(['list-todo']);
      Swal.fire({
        type:"success",
        title:"Login Successful..!",
        text:"Can Check Your List"
      })
    }
    else{
    
      this.invalidLogin = true;
      Swal.fire({
        type:"error",
        title:"OOPS...!",
        text:"Login Failed..!"
      })
    }
  }
}
