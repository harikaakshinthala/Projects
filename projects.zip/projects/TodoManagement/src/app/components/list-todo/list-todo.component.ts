import { Component, OnInit } from '@angular/core';
import { Todo } from 'src/app/model/todo.model';
import { Router } from '@angular/router';
import { TodoService } from 'src/app/services/todo.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-list-todo',
  templateUrl: './list-todo.component.html',
  styleUrls: ['./list-todo.component.css']
})
export class ListTodoComponent implements OnInit {

  todos: Todo[]
  

  constructor(private router: Router, private todosService: TodoService) { }

  logOutTodo(): void {
    if (localStorage.getItem("username") != null) {
      localStorage.removeItem("username");
      this.router.navigate(['/login']);
    }
  }

  deleteTodo(todo: Todo): void {
    let result = confirm("Do you want to delete Todo ?");

    if (result) {
      this.todosService.deleteTodo(todo.id).subscribe(data => {
        this.todos = this.todos.filter(u => u! == todo);
      })
      Swal.fire({
        type:"success",
        title:"Successfull ...",
        text:"record deleted successfully..!"});
    }
  }

  editTodo(todo: Todo): void {

    this.router.navigate(['edit-todo', todo.id.toString()]);

  }


  addTodo(): void {
    
    this.router.navigate(['add-todo']);
   
  }

  ngOnInit() {
    if (localStorage.getItem("username") != null) {
      this.todosService.getTodos().subscribe(data => {
        this.todos = data;
      });
    }
    else {
      this.router.navigate(['/login']);
    }
  }


}
