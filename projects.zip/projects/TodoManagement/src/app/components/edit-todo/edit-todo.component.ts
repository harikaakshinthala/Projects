import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Todo } from 'src/app/model/todo.model';
import { TodoService } from 'src/app/services/todo.service';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-todo',
  templateUrl: './edit-todo.component.html',
  styleUrls: ['./edit-todo.component.css']
})
export class EditTodoComponent implements OnInit {

  
  editForm: FormGroup;
  submitted: boolean;
  todo: Todo
  todoId: string;

  constructor(private todosService:TodoService, private route:ActivatedRoute,
    private formBuilder:FormBuilder, private router: Router) {
      this.route.params.subscribe(params => this.todoId = params['id']);
      console.log(this.todoId);
     }

     logOutTodo(): void {
      if (localStorage.getItem("username") != null) {
        localStorage.removeItem("username");
        this.router.navigate(['/login']);
      }
    }

  ngOnInit() {
    if(this.todoId != null){
      if(!this.todoId){
        Swal.fire({
          type:'error',
          title:'Invalid',
          text:'Invalid Details'
        });
        this.router.navigate(['list-todo']);
        return;
      }

      this.editForm = this.formBuilder.group({
        id: [],
      todoName: ['', [Validators.required, Validators.pattern("[A-Z][a-z]{4,29}")]],
      todoStatus: ['', Validators.required],
     
      });

      this.todosService.getTodosById(+this.todoId).subscribe(data => {
        this.editForm.setValue(data)
      });
    }
    else
    {
      this.router.navigate(['/login']);
    }
  }

  onSubmit(){
    this.submitted = true;
    if(this.editForm.invalid){
      return;
    }

    this.todosService.updateTodo(this.editForm.value).subscribe(data => {
      this.router.navigate(['list-todo']);
    },
    error=>{
      alert(error);
    });
  }

}
