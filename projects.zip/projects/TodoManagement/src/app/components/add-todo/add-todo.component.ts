import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TodoService } from 'src/app/services/todo.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-add-todo',
  templateUrl: './add-todo.component.html',
  styleUrls: ['./add-todo.component.css']
})
export class AddTodoComponent implements OnInit {

  
  addForm: FormGroup;
  submitted: boolean = false;
  
  constructor(private todosService:TodoService,private formBuilder:FormBuilder,
    private router:Router) { }

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id: [],
      todoName: ['', [Validators.required, Validators.pattern("[A-Z][a-z]{4,29}")]],
      todoStatus: ['', Validators.required]      
    });
  }

  onSubmit() {

    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }
    console.log(this.addForm.value);
    this.todosService.createTodo(this.addForm.value).subscribe(data => {

      Swal.fire({
        type:'success',
        
        title:"Successful..!",
        text:"Successfully Added"
      });

      // alert(this.addForm.controls.todoName.value + ' record is added successfully ..!');
      this.router.navigate(['list-todo']);
    })
  }

}
