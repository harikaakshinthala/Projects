import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'name'
})
export class NamePipe implements PipeTransform {

  transform(todosList: any, searchText: any) {
    let updatedTodosList: any;

    if(searchText)
    updatedTodosList = todosList.filter(todo => todo.todoName.toLowerCase()
    .startsWith(searchText.toLowerCase()))
    else
     updatedTodosList = todosList;

    return updatedTodosList;
  }
}
