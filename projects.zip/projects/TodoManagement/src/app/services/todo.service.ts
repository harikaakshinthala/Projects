import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Todo } from '../model/todo.model';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  constructor(private http:HttpClient) { }

  baseUrl:string = "http://localhost:3000/todo";

   //get all todos
   getTodos(){
    return this.http.get<Todo[]>(this.baseUrl);
  }

  //get todos by id
  getTodosById(id:number){
    return this.http.get<Todo>(this.baseUrl+ "/" +id);
  }

  //add todo
  createTodo(todo: Todo){
    return this.http.post(this.baseUrl,todo);
    //here user in parantheses is body of user
  }

  //modify todo
  updateTodo(todo:Todo){
    return this.http.put(this.baseUrl+ '/' +todo.id,todo);
  }

  //delete todo
  deleteTodo(id:number){
    return this.http.delete(this.baseUrl+ "/" +id);

  }
}
